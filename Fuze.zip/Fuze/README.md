The Fuze.h and Fuze.cpp files don't do anything, use the Examples to load up sample code.
